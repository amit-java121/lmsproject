package com.orenda.software.service;

public interface IUserLoginService {
	public boolean verifyUserCredentials();
	

}
