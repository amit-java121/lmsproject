package com.orenda.software.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/home")
public class UserLoginController {
	
	@GetMapping("/homePage")
	public String homePage() {
		
		return "home";
	}
	
	

}
