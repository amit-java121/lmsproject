package com.orenda.software.model;

public class UserLoginModel {

}
