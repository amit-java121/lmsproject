package com.orenda.software.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.orenda.software.model.UserLoginModel;

@Repository
public interface IUserLoginRepository extends JpaRepository<UserLoginModel, Integer>{

}
