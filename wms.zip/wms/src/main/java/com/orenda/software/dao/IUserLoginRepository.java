package com.orenda.software.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface IUserLoginRepository {

}
