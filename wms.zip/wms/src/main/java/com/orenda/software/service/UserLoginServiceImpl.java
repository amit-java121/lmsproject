package com.orenda.software.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orenda.software.dao.IUserLoginRepository;

@Service
public class UserLoginServiceImpl implements IUserLoginService{
	
	@Autowired
	IUserLoginRepository userRepository;

	@Override
	public boolean verifyUserCredentials() {
		// TODO Auto-generated method stub
		return false;
	}
	

}
