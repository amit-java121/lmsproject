package com.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.dao.ILoginRepository;
import com.springboot.model.User;

@Service
public class UserLoginImpl implements IUserLogin{
	
	@Autowired
	ILoginRepository repository;

	@Override
	public List<User>  getUserDeatils() {
		
		List<User> user = repository.findAll();
		
		
		return user;
	}

	@Override
	public boolean getUserByEmailId(String username,String password) {
		User user = repository.findByUserName(username);
		System.out.println(":::::: "+username);
		if(null != user && username.equalsIgnoreCase(user.getUserName()) && user.getUserPass().equalsIgnoreCase(password)) {
			return true;
		}
		
		return false;
		
		
	}
	
	

}
