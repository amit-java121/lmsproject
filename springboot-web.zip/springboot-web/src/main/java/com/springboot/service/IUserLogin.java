package com.springboot.service;

import java.util.List;

import com.springboot.model.User;

public interface IUserLogin {
	
	public List<User> getUserDeatils();

}
