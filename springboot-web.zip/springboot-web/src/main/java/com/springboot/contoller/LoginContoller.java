package com.springboot.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springboot.model.User;
import com.springboot.service.IUserLogin;

@Controller
public class LoginContoller {
	
	@Autowired
	IUserLogin loginService;
	
	@GetMapping("/")
	public String login() {
		System.out.println("we are in login method::");
		return "login";
	}
	
	@GetMapping("/login")
	public void getUserDetails(@RequestParam("username") String username, @RequestParam("password") String password) {
		System.out.println(username+"  "+password);
		
		List<User> userList = loginService.getUserDeatils();
		
		System.out.println(userList.toString());
		
	}

}
